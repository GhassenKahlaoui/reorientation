function AddPanier(user) {
   // alert("Bonjour");
}