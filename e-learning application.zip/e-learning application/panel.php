<?php 
error_reporting(0);
include "config.php" ; 
$num = rand(10,1000);
/*if(Connexion::getInstance())
$queryCount = "select * from utilisateur_panier";
$queryexec = mysqli_query(Connexion::getInstance(),$queryCount);
$number= intval(mysqli_num_rows($queryexec)) +1;
 echo $req = "insert into utilisateur_panier Values('$number','$_GET[user]','$_GET[idAnimation]')"; 
 $execinserrt= Connexion::query($req) ; 
if($execinserrt)
echo "Success";*/
?>