<?php 
/****************Description : Cette classe permet de gestionner un Evennement*********************** */
/**************************Version :1.0**************************** */
/**************************Developer : kahlaoui Mohamed Ghassen ************* */
class GestionEvent  {

  // cette fonction permet d'ectraire tous les evéennements 
  public static function getAllEvent() {

    $AllEvent = Array();          // c'est un conteneur des events  
  $sql = "select * FROM evennement"; // select depuis la base
  $result = mysqli_query(Connection::getInstance(), $sql); // exécuter la requette
  
  if (mysqli_num_rows($result) > 0) { //tester si il ya des champs 

      while($row = mysqli_fetch_assoc($result)) { //  creer des objets 
        $ev = new Event($row['idevennement'],$row['NomEvenement'],$row['description'],$row['date'],$row['imagename']); 
        array_push($AllEvent,$ev); // et j'ajouter au tableau 
        
      }
  
  }
  return $AllEvent ; // retourner le tableau des objets
}  

  // cette fonction permet d'ajouter un nouvelle evenemment depuis un formulaire vers une base de donée
    public static function AjoutEvent($id,$nomEvent,$description,$Date,$imagename) {
      
       
       $req  = "insert into evennement Values (".$id."  ,'".$nomEvent."','".$description."','".$Date."','".$imagename ."')" ;
       
        if(mysqli_query(Connection::getInstance(),$req))
         echo "<h1 class='alert alert-success'>Ajout Avec succee</h1>";
         else
         echo "<h1 class='alert alert-warning'>Erreur !</h1>"; 
       ;}
  
       public static function ShowFormEditEevent($idEventEdit) {
            echo "<form method='POST'>";
            echo "<table class='table darked'> <th> Numero de Cours</th><th> Nouveau Nom de Cours </th> <th> Nouveau Description</th> <th> Nouveau Date</th><th>Mise a jours</th> ";
          foreach(GestionEvent::getAllEvent() as $value)
                  if($value->getId() == $idEventEdit )
                            
                  {
                     echo "<tr><td> <input type='text' size='2px' name='nvID' value='".$value->getId()."'</td>";   
                    echo "<td><input type='text' name='nvNom' value='" . $value->getNomEvent()."'></td>";
                      echo "<td><textarea name='nvDescription'>" . $value->getDescriptionEvent()."</textarea></td>"; 
                      echo "<td><input type='date' name='nvDate' value='" . $value->getDateEvent()."'></td>";  
                      echo "<td><input  type='submit' class='btn btn-link' name='EditBtn' value='Modifier'></td></tr>";

                    }

                      echo "</table>";
                      echo "</form>";

       }


    public static function EditEvent($idEvent, $nvNom,$nvDes,$nvDate)  {
      
    $req_imageFromDBTxt = "select * from evennement where idevennement = " . $idEvent ;
    $_imageFromBD_query = mysqli_query(Connection::getInstance(),$req_imageFromDBTxt);  
   
    // extraire le nom de l'image depuis la BD 
    while($result = mysqli_fetch_assoc($_imageFromBD_query)) {
      $imgindb = $result['imagename'] ; 
    }
  

    // faire la mise a jours 
    $requ = "update evennement set NomEvenement='".$nvNom."', description = '".$nvDes ."', date='".$nvDate."' where idevennement = ". $idEvent. "" ;
     if(mysqli_query(Connection::getInstance(),$requ))
     echo "<h1 class='alert alert-success'>Modification  Avec succee</h1>";
         else
         echo "<h1 class='alert alert-warning'>Erreur lors de modification !</h1>"; 
       //echo $requ ;
      // header('location:personne.php'); 
        
        }   
    public static function DeleteAllEvent() {}
    public static function DeleteEventById($d) {
      $req = "delete  from evennement where idevennement =" . $d. "";
     
      if(mysqli_query(Connection::getInstance(), $req))
      echo "<script>alert('Supression avec sucée ')</script>";
    
    
    }

    public static function GererHtml () {


      $header ="<meta charset='utf-8'><link rel='stylesheet' href='styles/Styleevent.css'>";
      $fevent = fopen("p4index.html","w");

$msg = "<div id='NosEvents' class='AllEventContainer container'>
";
foreach(GestionEvent::getAllEvent() as $values)
{
    $msg.= "<div class='cdinfo card'>";
    
    $msg.= "<div class='card-header'  ><a href=#  onclick='alert('En cours ...')' style='margin-left:500px; background-color:#00a8ff ; padding:20px; text-decoration:none; color : #ecf0f1;'class='btn btn-primary'>Ajouter Aux Panier</a><h5> Nom de Cours : ".$values->getNomEvent() ."</h5>"."<h5 class='date'> Date de Creation de Cours". $values->getDateEvent()."</h5></div>";
    
   // $msg.= "<img alt='card image' class='card-img-top' width='2px' src=pictures/".$values->getImageName()." alt='Evennement pictures'>";
     $msg.= "<video controls class='card-img-top' width='320' height='240'>";
     $msg.="<source src=pictures/".$values->getImageName()." type='video/mp4'>";
     $msg.="<source src=pictures/".$values->getImageName()." type='video/ogg'></video>";
 
    $msg.= "<div class='card-body text-center'>".$values->getDescriptionEvent() . "</div>";
   
    
    $msg.= "</div>";

    $msg.= "<br>";
   
}


fwrite($fevent,$header);

fwrite($fevent,$msg);

  }
  

  } // end of class



?>