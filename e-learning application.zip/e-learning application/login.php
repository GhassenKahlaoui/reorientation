
<header>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Authenitifié </title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <header>
<?php 

session_start(); 
include("Model.php");

?>
<script>
function setModal() {
  var load = false ; 
  if(load ==false) {
  document.getElementById('id01').style.display='block';
    load = true ;
}
}

</script>
<body onload="setModal()">
    

<div class="jumbotron" >
<center><h1 style='margin-top:-4%'>Pourquoi Nous Choisir?</h1></center>
<table class='table'>
<tr>

<td>


<div class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;' > Éducation pour tous</h4></center>
    <center>
    <p class="card-text">Notre programme est accessible partout <br> et couvre des domaines demandés fortemant aujourd'hui.</p>
    </center>
</div>


</td>


<td>


<div class="card">
  <div class="card-body">
    <h4 class="card-title">Meilleurs formateurs
</h4>
<center>
    <p class="card-text">Vous serez conduits par des instituteurs <br> bien formés et ambitueux
</p>
    
    </center>
  </div>
</div>


</td>

<td>


<div class="card">
  <div class="card-body">
    <h4 class="card-title">Coûts imbattables</h4>
    <center>
    <p class="card-text">Profitez des leçons a haut niveaux <br> avec des prix a bas niveaux</p>
    </center>
  </div>
</div>


</td>

</tr>
</table>

</div>



<div class="container">
<h3> Authentification Administrateur </h3>
<label ><a href="">Acceuil</a> /login</label>
<form method="POST">
<table class='table'>
<tr><td><label>Email |<a href="" > Email Oublié </a ></label> <input type="text" name="EmailLogin" class="form-control"></td></tr>
<tr></tr>
<tr><td><label>Mot de passe |<a href="" > Mot de passe Oublié </a ></label> <input type="password" class="form-control" name="MotdePasseLogin"></td></tr>
<tr></tr>
<tr><td><input type="submit" class="btn btn-success" name='BTNLogin' value="Authentifier"></td><td><input type="reset" class="btn btn-warning" value="Annuler"></td></tr>
</table>
</form>
<?php 
 if(isset($_POST['BTNLogin'])) {

 
 echo Client::login($_POST['EmailLogin'],$_POST['MotdePasseLogin']);
    //echo "success";
 }
    //header("location:Commander.php?user=".$_SEESION["user"]); 

?>
<footer>

<div class="container"  style= 'box-shadow:  -30px -30px 50px #95a5a6'>
<p>
<img src="img/itplus.png" alt="itplus logo"> 
incubé dans l’association SAMA TOUNES émanant du programme Fikra du l’union européen  qui soutien les nouveaux idées du projet socio-économique  dans la nord ouest Phase II 2014.Le centre a pour objectif de mettre «  la technologie »  au service des enfants des zones les plus défavorisées, notamment dans les zones rurales et plus particulièrement dans les établissements scolaires et les maisons de jeunes des zones rurales ainsi que les espaces culturels similaires et ce durant les fins de semaines et les vacances scolaires.Ceci se traduirait par l’organisation de cycles de formation et d’animation informatique et technologiques ainsi que  l’initiation à l’utilisation de l’internet pour les enfants et les jeunes . Ces derniers seront initiés aux traitements des textes, à la programmation ainsi qu’à la conception des projets multimédias etc…Plus encore, ce projet est ambitieux et vise à organiser des compétitions régionales, nationales, voire internationales  dans le domaine de l’informatique pour les enfants et les jeunes.
</div>
</p>
<table class='table table-info'>
<tr><td>
&copy; SAN 2020
</td>
<td><img src="img/place.png" alt="Email" width='20px'>   02 rue Erriadh cité Erriadh, Jendouba  </td> <td> <img src="img/Email.png" alt="Email" width='20px'>   samatounes2012@gmail.com</td> <td><img src="img/phone.png" alt="Email" width='20px'>    +216 50442337</td>
</tr>
</table>

</footer>

<style>
.card-title:nth-child(1) {
    
    width:250px;
}
.jumbotron {
    box-shadow:20px 20px 30px #34495e ;  
}
.card-title {
    margin-left:20%;
}
body {
    background-image : url("img/itplus.png");
    
    background-repeat : no-repeat;
    background-position: 90% 62%;
}
</style>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!---button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Open Modal</button---->

<div id="id01" class="w3-modal">
  <div class="w3-modal-content">
    <header class="w3-container w3-teal"> 
      <span onclick="document.getElementById('id01').style.display='none'" 
      class="w3-button w3-display-topright">&times;</span>
      <h2><img class='model_info' src="img/itplus.png" alt="itplus logo"> itplus</h2>
    </header>

    <div class="container"  style= 'box-shadow:  -30px -30px 50px #95a5a6'>
<p>
<img src="img/itplus.png" alt="itplus logo"> 
incubé dans l’association SAMA TOUNES émanant du programme Fikra du l’union européen  qui soutien les nouveaux idées du projet socio-économique  dans la nord ouest Phase II 2014.Le centre a pour objectif de mettre «  la technologie »  au service des enfants des zones les plus défavorisées, notamment dans les zones rurales et plus particulièrement dans les établissements scolaires et les maisons de jeunes des zones rurales ainsi que les espaces culturels similaires et ce durant les fins de semaines et les vacances scolaires.Ceci se traduirait par l’organisation de cycles de formation et d’animation informatique et technologiques ainsi que  l’initiation à l’utilisation de l’internet pour les enfants et les jeunes . Ces derniers seront initiés aux traitements des textes, à la programmation ainsi qu’à la conception des projets multimédias etc…Plus encore, ce projet est ambitieux et vise à organiser des compétitions régionales, nationales, voire internationales  dans le domaine de l’informatique pour les enfants et les jeunes.
</div>
</p>

    
    <div class="w3-container">
    <iframe width="560" height="315" src="https://www.youtube.com/embed/8nCWNJ8NpOY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <footer class="w3-container w3-teal">
      <p>&copy; SAN 2020</p>
    </footer>
  </div>
</div>
</div>
</body>


<style>
.model_info {
    width:50px;
    height:50px;
    border-radius:100px;

}

</style>