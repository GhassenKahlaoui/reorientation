tabobject = [] ;
$(document).ready(function() {
    
    $(".date").hide() ;
    $(".cdinfo").mouseenter(function() {
        $("h5",this).show(1000);
        $("h3",this).css("color","#95a5a6");
        $(".card-body",this).animate({marginBottom: "-=40px"});
        $(this).animate({
            borderRightWidth: "+15px",
            position:"absolute"
        },"slow");
        
    });


    $(".cdinfo").mouseleave(function() {
        $("h5",this).hide(1000);
        $("h3",this).css("color","#95a5a6");
        $(".card-body",this).animate({marginBottom: "+=40px"});
        $(this).animate({
            borderRightWidth: "-15px"
        },"slow");
   
    })
});