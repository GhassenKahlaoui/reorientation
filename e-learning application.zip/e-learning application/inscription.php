<?php 
include "GererUtilisateur.php";
$code_string = explode("/",$_SERVER['PHP_SELF']); 
//cho "Code =". $code_string[4] ; 
?>
<header>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <header>

<body>
<div class="jumbotron" >
<center><h1 style='margin-top:-4%'>Pourquoi Nous Choisir?</h1></center>
<table class='table'>
<tr>

<td>


<div class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;' > Éducation pour tous</h4></center>
    <center>
    <p class="card-text">Notre programme est accessible partout <br> et couvre des domaines demandés fortemant aujourd'hui.</p>
    </center>
</div>


</td>


<td>


<div class="card">
  <div class="card-body">
    <h4 class="card-title">Meilleurs formateurs
</h4>
<center>
    <p class="card-text">Vous serez conduits par des instituteurs <br> bien formés et ambitueux
</p>
    
    </center>
  </div>
</div>


</td>

<td>


<div class="card">
  <div class="card-body">
    <h4 class="card-title">Coûts imbattables</h4>
    <center>
    <p class="card-text">Profitez des leçons a haut niveaux <br> avec des prix a bas niveaux</p>
    </center>
  </div>
</div>


</td>

</tr>
</table>
<div class="Apprenenant_Inscription">
<? 
function AfficheFormulaire ($code_string) { 
      if($code_string[3] !="")
      echo "
      
      <form method='POST'>
<table  class='table table-darked'>
<tr>
<td><label for='CodeUser'>Code Utilisateur </label></td>
<td><input type='text' class='form-control' name='CodeUser' id='CodeUser' value=$code_string[3] ></td>
</tr>
<tr>
<td><label for='CinApp'>Cin de l'apprenant</label></td>
<td><input type='text' class='form-control' name='CinApp' id='CinApp' value='Enter Votre Cin'></td>
</tr>
<tr>
<td><label for='Nom'>Nom</label></td>
<td><input type='text' class='form-control' name='nom' id='Nom' value='Enter Votre Nom'></td>
</tr>
<tr>
<td><label for='Pnom'>Prénom</label></td>
<td><input type='text' class='form-control' name='Pnom' id='Pnom' value='Enter Votre Prénom'></td>
</tr>
<tr>
<td><label for='Email'>Email</label></td>
<td><input type='Email' class='form-control' name='Email' id='Email' value='Enter Votre Email'></td>
</tr>
<tr>
<td><label for='passwd'>Mot de passe</label></td>
<td><input type='passeword' class='form-control' name='passwd' id='paswwd' value='Enter Votre Mot de passe'></td>
</tr>
<tr>

</tr>
<tr>
<td> <button class='btn btn-success' name='BtnSAvugerade'>Enregistrer</button>  </td>
<td><button class='btn btn-warning'>anuler</button> </td>
</tr>

</table>
 

</form>


      
      
      "
;
if($code_string[3] =="")

 {
   
  echo "
  
  
        
  <form method='POST'>
  <table  class='table table-darked'>
  
  <tr>
  <td><label for='CinApp'>Cin de l'apprenant</label></td>
  <td><input type='text' class='form-control' name='CinApp' id='CinApp' value='Enter Votre Cin'></td>
  </tr>
  <tr>
  <td><label for='Nom'>Nom</label></td>
  <td><input type='text' class='form-control' name='nom' id='Nom' value='Enter Votre Nom'></td>
  </tr>
  <tr>
  <td><label for='Pnom'>Prénom</label></td>
  <td><input type='text' class='form-control' name='Pnom' id='Pnom' value='Enter Votre Prénom'></td>
  </tr>
  <tr>
  <td><label for='Email'>Email</label></td>
  <td><input type='Email' class='form-control' name='Email' id='Email' value='Enter Votre Email'></td>
  </tr>
  <tr>
  <td><label for='passwd'>Mot de passe</label></td>
  <td><input type='passeword' class='form-control' name='passwd' id='paswwd' value='Enter Votre Mot de passe'></td>
  </tr>
  <tr>
  
  </tr>
  <tr>
  <td> <button class='btn btn-success' name='BtnSAvugerade'>Enregistrer</button>  </td>
  <td><button class='btn btn-warning'>anuler</button> </td>
  </tr>
  
  </table>
   
  
  </form>
  
  
  ";
 }


} 
echo "<precode>";
print_r($code_string) ;
echo "</precode>";
AfficheFormulaire($code_string);



?> 



</div>
<footer style='background-color:#ecf0f1;color:#1abc9c; '>
<h3 style='margin-left:800px'>&copy; SAN 2020</h3>

</footer>
<?php 
//$CinApprenant , $Emailpprenant, $NomApprenant , $PrenomApprenant, $MPS_Apprenent
if(isset($_POST['BtnSAvugerade'])) {
$App  = new Apprenent($_POST['CinApp'],$_POST['Email'],$_POST['Nom'],$_POST['Pnom'],$_POST['passwd']) ; 
$App->AjoutApprenant();
$App->AjoutCode($_POST['CodeUser']);

}
?>
</body>

<style>

.Apprenenant_Inscription {
    margin-left:10%;
    margin-top:8%;
}


</style>

<style>
.card-title:nth-child(1) {
    
    width:250px;
}
.jumbotron {
    box-shadow:20px 20px 30px #34495e ;  
}
.card-title {
    margin-left:20%;
}
body {
    background-image : url("img/itplus.png");
    
    background-repeat : no-repeat;
    background-position: 90% 62%;
}
</style>