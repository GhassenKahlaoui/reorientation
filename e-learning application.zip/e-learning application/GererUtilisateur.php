<?php
include "config.php" ; 
class Anim {
    public $idAnimation , $NomAnimation , $DescriptionAnimation,$DateAnimation,$TitreAnimation;

    public function __construct($idAnimation , $NomAnimation , $DescriptionAnimation,$DateAnimation,$TitreAnimatio) {
        $this->idAnimation = $idAnimation;
        $this->NomAnimation = $NomAnimation;
        $this->DescriptionAnimation = $DescriptionAnimation;
        $this->DateAnimation = $DateAnimation ; 
        $this->TitreAnimation  =$TitreAnimation;
    }
    public function getidAnimation() { return $this->idAnimation ;}
  public function getNomAnimation() {return $this->NomAnimation;}
  public function getDescriptionAnimation() {return $this->DescriptionAnimation;}
  public function getDateAnimation() {return $this->DateAnimation;}
  public function getTitreAnimation() {return $this->TitreAnimation;}

}

class Animation {

    

     // cette fonction permet d'ectraire tous les evéennements 
  public static function getAllAnimation() {

    $AllAnimation = Array();          // c'est un conteneur des events  
  $sql = "select * FROM animation"; // select depuis la base
  $result = mysqli_query(Connexion::getInstance(), $sql); // exécuter la requette
  
  if (mysqli_num_rows($result) > 0) { //tester si il ya des champs 

      while($row = mysqli_fetch_assoc($result)) { //  creer des objets 
        $ev = new Anim($row['ident_Animation'],$row['NomAnimation'],$row['DescriptionAnimation'],$row['Date_De_Creation'],$row['Nom_animation']); 
        array_push($AllAnimation,$ev); // et j'ajouter au tableau 
        
      }
  
  }
  return $AllAnimation;
}

    public static function AjoutAnimation($id,$nomEvent,$description,$Date,$imagename) {
        $reqIn = "insert into animation Values('$id','$nomEvent','$description','$Date','$imagename') ";
    //$req  = "insert into evennement Values (".$id."  ,'".$nomEvent."','".$description."','".$Date."','".$imagename ."')" ;
       echo $reqIn;
    if(mysqli_query(Connexion::getInstance(),$reqIn))
     echo " <h1 class='alert alert-success'>Ajout Avec succee <img src='img/success.png' width='20px'></h1>";
     else
     echo "<h1 class='alert alert-warning'>Oops !! Erreur lors de l'ajout !<img src='img/sad.jpg' width='70px'></h1>"; 
   ;}



   public static function EditEvent($idEvent, $nvNom,$nvDes,$nvDate)  {
      
    $req_imageFromDBTxt = "select * from animation where ident_Animation = " . $idEvent ;
    $_imageFromBD_query = mysqli_query(Connexion::getInstance(),$req_imageFromDBTxt);  
   
    // extraire le nom de l'image depuis la BD 
    while($result = mysqli_fetch_assoc($_imageFromBD_query)) {
      $imgindb = $result['imagename'] ; 
    }
  

    // faire la mise a jours 
    $requ = "update  animation set 	NomAnimation='".$nvNom."', DescriptionAnimation = '".$nvDes ."', Date_De_Creation='".$nvDate."' where ident_Animation = ". $idEvent. "" ;
     if(mysqli_query(Connexion::getInstance(),$requ))
     echo "<h1 class='alert alert-success'>Modification  Avec succee</h1>";
         else
         echo "<h1 class='alert alert-warning'>Erreur lors de modification !</h1>"; 
       //echo $requ ;
      // header('location:personne.php'); 
        
        }   



        public static function ShowFormEditEevent($idEventEdit) {
            echo "<form method='POST'>";
            echo "<table class='table darked'> <th> Numero de l'Animation</th><th> Nouveau Nom de l'Animation </th> <th> Nouveau Description</th> <th> Nouveau Date</th><th>Mise a jours</th> ";
          foreach(Animation::getAllAnimation() as $value)
                  if($value->getidAnimation() == $idEventEdit )
                            
                  {
                     echo "<tr><td> <input type='text' size='2px' name='nvID' value='".$value->getidAnimation()."'</td>";   
                    echo "<td><input type='text' name='nvNom' value='" . $value->getNomAnimation()."'></td>";
                      echo "<td><textarea name='nvDescription'>" . $value->getDescriptionAnimation() ."</textarea></td>"; 
                      echo "<td><input type='date' name='nvDate' value='" . $value->getDateAnimation()."'></td>";  
                      echo "<td><input  type='submit' class='btn btn-link' name='EditBtn' value='Modifier'></td></tr>";

                    }

                      echo "</table>";
                      echo "</form>";

       }

       public static function DeleteAnimationById($d) {
        $req = "delete  from animation where ident_Animation ='" . $d. "'";
       
        if(mysqli_query(Connexion::getInstance(), $req))
        echo "<script>alert('Supression avec sucée ')</script>";
      
      
      }



      
// gerer HTML FILE 




public static function GererHtml () {

  //href=Panel.php?user=$_SESSION[user]&&idAnimation=".$values->getidAnimation()." 
  //$user_email  = $_SESSION['user']+":"+$values->getidAnimation();
  
    $header ="<meta charset='utf-8'><link rel='stylesheet' href='styles/Styleevent.css'> <script src='panel1.js'></script> ";
    $fevent = fopen("p4index.html","w");

$msg = "<div id='NosEvents' class='AllEventContainer container'>
";
foreach(Animation::getAllAnimation() as $values)
{
  $msg.= "<div class='cdinfo card'>";
  $msg.="<div style='' > </div>";
  $user_email_idAnimation  = $_SESSION['user'].":".$values->getidAnimation();
  $msg.= "  <div class='card-header' )'><img style='cursor:pointer' src='img/like.png' style='margin-top:50px' width='30px'><img src='img/DLK.png' style='cursor:pointer' width='30px'><img src='img/heart.png' style='cursor:pointer'  width='30px'><a    style='margin-left:400px; background-color:#00a8ff ; padding:20px; cursor:pointer; text-decoration:none; color : #ecf0f1;'class='btn btn-primary' onclick=AddPanier('".$user_email_idAnimation ."')>Ajouter Aux Panier</a><h5> Nom de l\'Animation : ".$values->getNomAnimation() ."</h5>"."<h5 class='date'> Date de Creation de Cours". $values->getDateAnimation()."</h5></div>";
  
 // $msg.= "<img alt='card image' class='card-img-top' width='2px' src=pictures/".$values->getImageName()." alt='Evennement pictures'>";
   $msg.= "<video controls class='card-img-top' width='320' height='240'>";
   $msg.="<source src=pictures/".$values->getTitreAnimation()." type='video/mp4'>";
   $msg.="<source src=pictures/".$values->getTitreAnimation()." type='video/ogg'></video>";

  $msg.= "<div class='card-body text-center'>".$values->getDescriptionAnimation() . "</div>";
  $msg.="";
  
  $msg.= "</div>";

  $msg.= "<br>";
 
}


fwrite($fevent,$header);

fwrite($fevent,$msg);

}





// end of function 


    
}

class Apprenent_structure {
    public $CinApprenent,$NomApprenent,$PrenomApprenent,$MPS_Apprenet,$Email_Apprenent; 
    public function __construct($CinApprenent,$NomApprenent,$PrenomApprenent,$MPS_Apprenet,$Email_Apprenent) {
        $this->CinApprenent = $CinApprenent;
        $this->NomApprenent = $NomApprenent;
        $this->PrenomApprenent = $PrenomApprenent;
        $this->MPS_Apprenet = $MPS_Apprenet ; 
        $this->Email_Apprenent  =$Email_Apprenent;
    }
    public function getCinApprenent() { return $this->CinApprenent ;}
    public function getNomApprenent() {return $this->NomApprenent;}
    public function getPrenomApprenent() {return $this->PrenomEncadreur;}
    public function getMPS_Apprenet() {return $this->MPS_Apprenet;}
    public function getEmail_Apprenent() {return $this->Email_Apprenent;}

}
class Encadreur_Structure {

    public $CinEncadreur,$NomEncadreur,$PrenomEncadreur,$MPS_Encadreur,$Email_Encadreur; 
    public function __construct($CinEncadreur,$NomEncadreur,$PrenomEncadreur,$MPS_Encadreur,$Email_Encadreur) {
        $this->CinEncadreur = $CinEncadreur;
        $this->NomEncadreur = $NomEncadreur;
        $this->PrenomEncadreur = $PrenomEncadreur;
        $this->MPS_Encadreur = $MPS_Encadreur ; 
        $this->Email_Encadreur  =$Email_Encadreur;
    }
    public function getCinEncadreur() { return $this->NomEncadreur ;}
  public function getNomEncadreur() {return $this->NomAnimation;}
  public function getPrenomEncadreur() {return $this->PrenomEncadreur;}
  public function getMPS_Encadreur() {return $this->MPS_Encadreur;}
  public function getEmail_Encadreur() {return $this->Email_Encadreur;}
}
class Encadreur {
    public $CinEncadreur,$NomEncadreur,$PrenomEncadreur,$MPS_Encadreur,$Email_Encadreur; 
    public function __construct($CinEncadreur,$NomEncadreur,$PrenomEncadreur,$MPS_Encadreur,$Email_Encadreur) {
        $this->CinEncadreur = $CinEncadreur;
        $this->NomEncadreur = $NomEncadreur;
        $this->PrenomEncadreur = $PrenomEncadreur;
        $this->MPS_Encadreur = $MPS_Encadreur ; 
        $this->Email_Encadreur  =$Email_Encadreur;
    }
    

    
public function AjouterEncadreur() {
    $query = "insert into Encadreur Values('$this->CinEncadreur','$this->NomEncadreur','$this->PrenomEncadreur' , '$this->MPS_Encadreur ' , '$this->Email_Encadreur' )"; 
if(Connexion::getInstance()) 
Connexion::query($query);
echo "Ajouter Encadreur Avec success";

}

     // cette fonction permet d'ectraire tous les evéennements 
     public static function getAllEncadreur() {

        $AllAnimation = Array();          // c'est un conteneur des events  
      $sql = "select * FROM encadreur  "; // select depuis la base
      $result = mysqli_query(Connexion::getInstance(), $sql); // exécuter la requette
      
      if (mysqli_num_rows($result) > 0) { //tester si il ya des champs 
    
          while($row = mysqli_fetch_assoc($result)) { //  creer des objets 
            $ev = new Encadreur_Structure($row['CinEncadreur'],$row['EmailEncadreur'],$row['NomEncadreur'],$row['PrenomEncadreur'],$row['MPS_Apprenant']); 
            array_push($AllAnimation,$ev); // et j'ajouter au tableau 
            
          }
      
      }
      return $AllAnimation;
}
}

class Apprenent {
    public $CinApprenant , $NomApprenant , $PrenomApprenant , $MPS_Apprenent , $Emailpprenant ; 
    public function __construct($CinApprenant , $Emailpprenant, $NomApprenant , $PrenomApprenant, $MPS_Apprenent  ) {
        $this->CinApprenant = $CinApprenant;
        $this->NomApprenant = $PrenomApprenant;
        $this->MPS_Apprenent = $MPS_Apprenent;
        $this->PrenomApprenant = $PrenomApprenant ; 
        $this->Emailpprenant  =$Emailpprenant;
    }

      // cette fonction permet d'ectraire tous les evéennements 
      public static function getAllApprenent() {

        $AllApprenent = Array();          // c'est un conteneur des events  
      $sql = "select * FROM apprenant  "; // select depuis la base
      $result = mysqli_query(Connexion::getInstance(), $sql); // exécuter la requette
      
      if (mysqli_num_rows($result) > 0) { //tester si il ya des champs 
    
          while($row = mysqli_fetch_assoc($result)) { //  creer des objets 
            $ev = new Apprenent_structure($row['CinApprenant'],$row['EmailApprenant'],$row['NomApprenant'],$row['PrenomApprenant'],$row['MPS_Apprenant']); 
            array_push($AllApprenent,$ev); // et j'ajouter au tableau 
            
          }
      
      }
      return $AllApprenent;
}

    public function AjoutApprenant() {
        $query = "insert into apprenant Values('$this->CinApprenant','$this->Emailpprenant','$this->NomApprenant' , '$this->PrenomApprenant' , '$this->MPS_Apprenent' )"; 
 if(Connexion::getInstance()) 
 Connexion::query($query);
 echo "Ajouter Apprenent Avec success";
  
 }
 public function AjoutCode($codeUtilisateur) {
   $query = "insert into apprenant_utilisatur(num,email,code) Values  (NULL,'$this->Emailpprenant','$codeUtilisateur') "; 
   echo $query ; 
   if(Connexion::getInstance()) 
 Connexion::query($query);
 echo "success";

 }
}

class Animateur {

public $CinAnimateur ,  $EmailAnimateur , $NomAnimateur, $PrenomAnimateur , $MPS_Animateur ;  
public function __construct($CinAnimateur ,  $EmailAnimateur , $NomAnimateur, $PrenomAnimateur , $MPS_Animateur ) {
    $this->CinAnimateur = $CinAnimateur;
    $this->EmailAnimateur = $EmailAnimateur;
    $this->NomAnimateur = $NomAnimateur;
    $this->PrenomAnimateur = $PrenomAnimateur ; 
    $this->MPS_Animateur  =$MPS_Animateur;
}
public function getCin() {$this->CinAnimateur;}

public function AjoutAnimateur() {
       $query = "insert into animateur Values('$this->CinAnimateur','$this->EmailAnimateur','$this->NomAnimateur' , '$this->PrenomAnimateur' , '$this->MPS_Animateur' )"; 
if(Connexion::getInstance()) 
Connexion::query($query);
echo "Ajouter Animateur Avec success";
 
}


}
if(isset($_GET['user']) && isset($_GET['type']))


if($_GET['type'] =="Encadreur") {


    $tab_user_inf = explode  (':',$_GET['user']);
//print_r($tab_user_inf);
$Encadreur = new Encadreur($tab_user_inf[0],$tab_user_inf[1],$tab_user_inf[2],$tab_user_inf[3],$tab_user_inf[4]);
echo $Encadreur->AjouterEncadreur();
//echo count($tab_user_inf); 



}

if(isset($_GET['user']) && isset($_GET['type'])) {
if($_GET['type'] =="Aprenent") {
$tab_user_inf = explode (':',$_GET['user']);
$Apprenent = new Apprenent($tab_user_inf[0],$tab_user_inf[1],$tab_user_inf[2],$tab_user_inf[3],$tab_user_inf[4]);
echo $Apprenent->AjoutApprenant();
//echo count($tab_user_inf); 
} else {
    if($_GET['type'] =="Animateur") {


        $tab_user_inf = explode  (':',$_GET['user']);
//print_r($tab_user_inf);
$Animateur = new Animateur($tab_user_inf[0],$tab_user_inf[1],$tab_user_inf[2],$tab_user_inf[3],$tab_user_inf[4]);
echo $Animateur->AjoutAnimateur();
//echo count($tab_user_inf); 



    }

    
}

}


?>