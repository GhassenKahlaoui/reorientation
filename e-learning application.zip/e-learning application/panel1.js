function AddPanier(user) {
    var xhttp;
    if (user.length == 0) { 
      document.getElementById("txtHint").innerHTML = "";
      return;
    }
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", "gethint.php?q="+str, true);
    xhttp.send();  
    res = user.split() 
     alert("Bonjour"+ user);
 }