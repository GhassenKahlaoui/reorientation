<header>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
    <script src='script/animation.js'>
</script>
<link rel="stylesheet" href="styles/styleA.css"> 
<script>

function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}
function AjouterEncadreur(chaine) {

  var CinEncadreur = document.getElementById('CinEncadreur').value ; 
  var NomEncadreur = document.getElementById('NomEncadreur').value ; 
  var PrenomEncadreur = document.getElementById('PrenomEncadreur').value ; 
  var EmailEncadreur = document.getElementById('EmailEncadreur').value ; 
  var pwdEncadreur = document.getElementById('pwdEncadreur').value ; 
  var AnimateurInfos =""; 
  AnimateurInfos = AnimateurInfos.concat(CinEncadreur).concat(":").concat(EmailEncadreur).concat(":").concat(NomEncadreur).concat(":").concat(PrenomEncadreur).concat(":").concat(pwdEncadreur);
  alert(AnimateurInfos);
  var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    }
    xmlhttp.open("GET", "GererUtilisateur.php?user="+AnimateurInfos+"&&type=Encadreur", true);
    xmlhttp.send();

}
function AjouterApprenant(chaine) {
  //.concat(":").concat(PnomAnimateur).concat(":").concat(PassewordAnimateur);
  var CinApprenant = document.getElementById('CinApprenant').value ; 
  var NomApprenant = document.getElementById('NomApprenant').value ; 
  var PrenomApprenant = document.getElementById('PrenomApprenant').value ; 
  var EmailApprenant = document.getElementById('EmailApprenant').value ; 
  var PwdApprenent = document.getElementById('PwdApprenent').value ; 
  var AnimateurInfos =""; 
  AnimateurInfos = AnimateurInfos.concat(CinApprenant).concat(":").concat(EmailApprenant).concat(":").concat(NomApprenant).concat(":").concat(PrenomApprenant).concat(":").concat(PwdApprenent);
  alert(AnimateurInfos);
  var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    }
    xmlhttp.open("GET", "GererUtilisateur.php?user="+AnimateurInfos+"&&type=Aprenent", true);
    xmlhttp.send();
  }

function AjoutAnimateur(chaine) {
 //.concat(":").concat(PnomAnimateur).concat(":").concat(PassewordAnimateur);
  var CinAnimateur = document.getElementById('CinAnimateur').value ; 
  var emailAnimatur = document.getElementById('emailAnimatur').value ; 
  var NomAnimateur = document.getElementById('NomAnimateur').value ; 
  var PnomAnimateur = document.getElementById('PnomAnimateur').value ; 
  var PassewordAnimateur = document.getElementById('PassewordAnimateur').value ; 
  var AnimateurInfos =""; 
  AnimateurInfos = AnimateurInfos.concat(CinAnimateur).concat(":").concat(emailAnimatur).concat(":").concat(NomAnimateur).concat(":").concat(PnomAnimateur).concat(":").concat(PassewordAnimateur);
  alert(AnimateurInfos);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    }
    xmlhttp.open("GET", "GererUtilisateur.php?user="+AnimateurInfos+"&&type=Animateur", true);
    xmlhttp.send();
  }

</script>
</script>
<?php
session_start();
 error_reporting(E_ALL||E_Notice);
 include("EventStructure.php");
 include("connexion.php");
 include("GestionEvent.php");
 include("GererUtilisateur.php");
$_SESSION["user"] = $_GET['user'];
?>


    <body>
      
    
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="p4index.html"><img src="img/itplus.png" style='width:50;height:50px; border-radius:50px'alt=""> Acceuil</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><img width='35px' src="img/cours.png" alt="cours">Gérer les cours </a>
      </li><li class="nav-item">
        <a class="nav-link" href="#"><img width='35px' src="img/formateur.png" alt="formateurs"> Gérer les Animateurs </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"> <img width='30px' src="img/Etudiant.png" alt="formateurs">Gérer les étudiants</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <?php  echo "<img  style='width:30px 'src='img/user.png' alt='user'> ". $_GET["user"] ; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href=""> <img src="img/user.png" width='40px' alt="">  <img src="img/settingProfile.png"style='margin-left:-18px'  width='20px' alt=""> Modifier Mes Informations Personnelles</a>
          <a class="dropdown-item" href="panel.php?user=<?php echo $_GET['user']; ?>"> <img src="img/lis.png" width='30px' alt=""> Mon paneau des Animationss </a>
          <a class="dropdown-item" href="deconnecter.php?user=<?php echo $_GET['user']; ?>"> <img src="img/exit.png" width='30px' alt=""> Deconnecter </a>
          
        </div>
      </li>
    </ul>
  </div>
</nav>
</fieldset>


<div class="jumbotron" >
<center><h1 style='margin-top:-4%'>Statistique </h1></center>
<table class='table'>
<tr>

<td>

<!--------Card statistique Cours-------->
<div style=';background-color: #2ecc71;  background-size:cover; bacground-position:7% 20% ' class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;'  > <?php echo count(Animation::getAllAnimation()); ?> Animation Ajouté</h4></center><center>
    <img src="img/Animation.png"  width='35px' alt="">  <img src="img/plus.png" style='margin-left:-18px'width='20px' alt=""> <a style='color:#f5f6fa;' href="">Ajouter Animation</a><img src="img/Animation.png" width='30px' alt=""> <a href="" style='color:#f5f6fa;' >Modifier Animation</a></center>
    </div>
    </div>
</td>
<td>

<!--------Card statistique Encadreur-------->

<div style=';background-color: #2ecc71;  background-size:cover; bacground-position:7% 20% ' class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;'  > <?php echo count(Encadreur::getAllEncadreur()); ?> Encadreur Ajouté</h4></center><center>
    <img src="img/Encadreur.png" width='40px' alt=""> <img src="img/plus.png" style='margin-left:-18px'width='20px' alt=""><a style='color:#f5f6fa;'href="">Ajouter Encadreur</a><img src="img/Encadreur.png" width='40px' alt="">  <a href="" style='color:#f5f6fa;' >Modifier Encadreur</a></center>
    </div>
    </div>
</td>
<td>


<!--------Card statistique Points et cadeaux-
<div style='background-color:#1abc9c;' class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;' > 0 point et cadeaux</h4></center>
    <center>
    <img src="img/cadeaux.png" width='30px' alt="">  <a href="" style='color:#f5f6fa;' >Gerer les Points et les cadeaux</a></center>
    </div>
    </div>
</td>

<td>
<td>
------->
<!--------Card statistique Animateur-------->

<div style='background-color:#1abc9c;' class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;' > <?php echo count(Encadreur::getAllEncadreur()); ?>  Animateur Ajouté</h4></center>
    <center>
    <img src="img/modifier.png" width='30px' alt="">  <a style='color:#f5f6fa;'href="">Ajouter Animateur</a> <img src="img/modifier.png" width='30px' alt="">    <a href="" style='color:#f5f6fa;' >Modifier Animateur</a></center>
    </div>
    </div>
</td>

<td>

<!--------Card statistique Etudiant-------->
<div style='background-color:#34495e; color:#ecf0f1;' class="card">
  <div class="card-body"><center>
    <h4 class="card-title" style='margin-left:20px;;' > <?php echo count(Apprenent::getAllApprenent()); ?>   Apprenant Ajouté</h4></center><center>
    <img src="img/Ajouter.png" width='30px' alt=""> <a style='color:#f5f6fa;'href="">Ajouter Etudiant</a> <img src="img/modifier.png" width='30px' alt=""> <a href="" style='color:#f5f6fa;' >Modifier Etudiant</a></center>
    </div>
    </div>
</td>


</tr>
</table>

</div>
<fieldset>  
<legend> <div data-toggle="modal" data-target="#myModal">   <img src="img/utilisateur.png"  width='40px' alt=""> <img src="img/plus.png" style='margin-left:-18px'width='20px' alt="">  Ajouter Utilisateur</div></legend>

</fieldset>

<fieldset>
<legend id="AddEvent">   <img src="img/Animation.png"  width='35px' alt="">  <img src="img/plus.png" style='margin-left:-18px'width='20px' alt=""> Ajouter Animation </legend>
<div >
 <style>
 td {
   color:white;
 }
 </style>
<form method="POST" enctype="multipart/form-data">
<table class="addEvent table table-bordred">
<div class="form-group">
<tr><td> Numero de l'animtion </td><td><input class="form-control" name="idEvent" type="number" min="1" max="1000"></td></tr>
<tr><td> Nom de l'animation </td><td> <input type="text" class="form-control" name="nomEvent"></td></tr>
<tr> <td> Description De l'animtion </td> <td><textarea class="form-control" name="descEvent"></textarea>
<tr> <td> Date de creation de l'animation</td><td><input class="form-control" type="date" name="dateEvent"></td></tr>
<tr> <td> Video de l'animation </td><td><input type='file' name='imgEvent' class="form-control"></td></tr>
<tr ><td colspan="2"> <input type="submit" name="send"  onclick="alert('valdier')"class="btn btn-primary "value="Ajouter Animation"></td>
</table>
</div>

<?php
if(isset($_POST['send']))
{
 $uploads_dir = 'pictures/';
 $name = $_FILES['imgEvent']['name'];
 $tmp_name = $_FILES['imgEvent']['tmp_name'];
if( move_uploaded_file($tmp_name,$uploads_dir.$name)) {
Animation::AjoutAnimation($_POST["idEvent"] , $_POST["nomEvent"],$_POST["descEvent"],$_POST["dateEvent"],$_FILES['imgEvent']['name']);

}
}
?>
</form>
 </div>
<!-----------Edit event---------->
<form method="POST">
<fieldset>
<legend id="ModifierEvent"> <img src="img/Animation.png"  width='35px' alt=""> <img src="img/Edit.png" style='margin-left:-18px'width='30px' alt=""> Modifier Une Animation </legend>


<form method="POST">
<table class=" ModifierEvent table table-darked">
<tr>
<td>
<select class="form-control" name="EditEvent">;
<?php 
if(count(Animation::getAllAnimation())== 0)
echo "<option disabled selected>Oops !! Aucune Animation Trouvé </option>";
else {

foreach(Animation::getAllAnimation() as  $value )
 {
    echo "<option value=".$value->getidAnimation().">Nom de l'animation :".$value->getNomAnimation(). "-Date de l'ajout de Cours : ".$value->getDateAnimation(). "</option>"; 

  }
}
?>
</td>
<td> <input type="submit" name="EditEventBtn" value="Modifier Animation" class="btn btn-warning">
</tr>
</select>
</form>
</fieldset>
<?php

if(isset($_POST['EditEventBtn']))
Animation::ShowFormEditEevent($_POST['EditEvent']);

if(isset($_POST['EditBtn'])) 
Animation::EditEvent($_POST['nvID'],$_POST['nvNom'],$_POST['nvDescription'],$_POST['nvDate']);
?>
</form>




<!----------Delete Event----------->

<form method="POST">
<fieldset>
<legend id="DeleteEvent"><img src="img/Animation.png"  width='35px' alt=""> <img src="img/delete.png" style='margin-left:-18px'width='30px' alt="">Supprimer Une Animation </legend>


<form method="POST">
<table class=" DeleteEvent table table-darked">
<tr>
<td>
<select class="form-control" name="DeleteEvent">;
<?php 

if(count(Animation::getAllAnimation())== 0)
  echo "<option>Aucune Cours</option>";
  else {
foreach(Animation::getAllAnimation() as  $value )
 {
    echo "<option value=".$value->getidAnimation().">Nom de l'animation  :".$value->getNomAnimation(). "-Date de l'animation : ".$value->getDateAnimation(). "</option>"; 

  }
}
 ?>
</td>
<td> <input type="submit" name="DeleteEventBtn" value="Supprimer Animation" class="btn btn-warning">
</tr>
</select>
</form>
</fieldset>
</form>

<?php 
if(isset($_POST['DeleteEventBtn']))
Animation::DeleteAnimationById($_POST['DeleteEvent']);
?>



<button style="border-radius:250px" name="SGHTML" class="btn btn-primary">  <img width='30px'src="img/setting.png" alt=""> Génere la page html des des Animations</button>
<?php 
if(isset($_POST['SGHTML']))
Animation::GererHtml() ;
?>
<br>
<table style=' margin-left:80%;margin-top:-420px; box-shadow:-20px 20px 30px #1abc9c '>
<tr>
<th><h3 style='padding:2px;font-family:Helvetica;background-color:#34495e;color:#3498db;'> <img src="img/friend.jpg" width='30px;' alt="">  Inviter Vos Amis</h3></th>
</tr>
<tr>

<td><input id="myInput"  class='form-control' type="text" value=<?php echo $_SERVER['SERVER_NAME'] ."/itplus/itplus/inscription/". $_SESSION['user'] ."/"?>></td>
<td>
<button class="btn btn-info" onclick="myFunction()">Copié le lien</button></td>
</tr>
</table>
 

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Ajouter Animateur / Etudiant</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          
<div class="container">
  <h2>Chosiir sur Une Option</h2>
  <hr>
  <p>Resultat: <span id="txtHint"></span></p>

   <div id="accordion">
    <div class="card">
      <div class="card-header">
        <a class="card-link" data-toggle="collapse" href="#collapseOne">
          Ajouter Animateur
        </a>
      </div>
      <div id="collapseOne" class="collapse show" data-parent="#accordion">
        <div class="card-body">
        <b>les champs en * Sont obligatoire</b> 
        <form>
        <div class="form-group">
    <label for="CinAnimateur">CIN de l'animateur:</label>
    <input type="number" class="form-control" max-length='8' placeholder="Enter CIN de l'animateur" id="CinAnimateur">
  </div>
  
  <div class="form-group">
    <label for="emailAnimatur">Email address:</label>
    <input type="email" class="form-control" placeholder="Enter l'email" id="emailAnimatur">
  </div>
  <div class="form-group">
    <label for="NomAnimateur">Nom de l'animateur:</label>
    <input type="text" class="form-control" placeholder="Enter NOM de l'animateur" id="NomAnimateur">
  </div>
  <div class="form-group">
    <label for="PnomAnimateur">Prénom de l'animateur:</label>
    <input type="text" class="form-control" placeholder="Enter le Prénom de l'animateur" id="PnomAnimateur">
  </div>
  <div class="form-group">
    <label for="passwordAnimateur">Mot de passe de l'animateur:</label>
    <input type="passeword" class="form-control" placeholder="Enter password" id="PassewordAnimateur">
  </div>
  
  <button type="button" class="btn btn-primary" onclick="AjoutAnimateur('E cours')">Ajouter Animateur</button>
</form>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <a class="collapsed card-link" data-toggle="collapse" href="#collapseTwo">
        Ajouter Apprenant
      </a>
      </div>
      <div id="collapseTwo" class="collapse" data-parent="#accordion">
        <div class="card-body">
         c'est quoi Apprenant ? 
         Apprenant c'est un citoyen Qui Veut Suivez Nos Animations 
         <form>
        <div class="form-group">
    <label for="CinApprenant">CIN de l'Apprenant:</label>
    <input type="number" class="form-control" placeholder="Enter CIN de l'Apprenant" id="CinApprenant">
  </div>
  <form>
        <div class="form-group">
    <label for="NomApprenant">Nom de l'Apprenant:</label>
    <input type="text" class="form-control" placeholder="Enter NOm de l'Apprenant" id="NomApprenant">
  </div>
  
  <div class="form-group">
    <label for="PrenomApprenant">Prenom de l'Apprenant:</label>
    <input type="text" class="form-control" placeholder="Enter Prenom de l'Apprenant" id="PrenomApprenant">
  </div>
  
  
  

  <div class="form-group">
    <label for="EmailApprenant">Email address:</label>
    <input type="email" class="form-control" placeholder="Enter email de l'apprenant" id="EmailApprenant">
  </div>
  <div class="form-group">
    <label for="PwdApprenent">Mot de Passe de L'apprenent :</label>
    <input type="password" class="form-control" placeholder="Enter password" id="PwdApprenent">
  </div>
  
  <button type="button" onclick="AjouterApprenant('En cours')"class="btn btn-primary">Ajouter Apprenant</button>
</form>
       
       
       
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <a class="collapsed card-link" data-toggle="collapse" href="#collapseThree">
          Ajouter Encadreur
        </a>
      </div>
      <div id="collapseThree" class="collapse" data-parent="#accordion">
        <div class="card-body">
          C'est quoi un Encadreur ? 
          Un Encadreur c'est un inspecteur de l'animation de L'animateur 
          <form action="/action_page.php">
        <div class="form-group">
    <label for="CinEncadreur">CIN de l'Encadreur:</label>
    <input type="number" class="form-control" placeholder="Enter CIN de l'Encadreur" id="CinEncadreur">
  </div>
  <div class="form-group">
    <label for="EmailEncadreur">Email de l'encadreur:</label>
    <input type="email" class="form-control" placeholder="Enter email" id="EmailEncadreur">
  </div>
  
  <div class="form-group">
    <label for="NomEncadreur">Nom de l'encadreur:</label>
    <input type="text" class="form-control" placeholder="Nom de l'encadreur" id="NomEncadreur">
  </div>
  <div class="form-group">
    <label for="PrenomEncadreur">Prénom de l'encadreur:</label>
    <input type="text" class="form-control" placeholder="Prénom de l'encadreur" id="PrenomEncadreur">
  </div>
  <div class="form-group">
    <label for="pwdEncadreur">Mot de passe de l'encadreur:</label>
    <input type="password" class="form-control" placeholder="Enter password" id="pwdEncadreur">
  </div>
  
  <button type="button" onclick="AjouterEncadreur('En cours')"class="btn btn-primary">Ajouter Encadreur</button>
</form>
      
        </div>
      </div>
    </div>
  </div>
</div>
    
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
        </div>
        
      </div>
    </div>
  </div>
  
</div>



<hr>

</body>
<style>
.GererAnimateur {
  color: #f5f6fa ;
  background-color : #00a8ff;
  
  width:100px;
  height:60px; 
}
.info_footer {
   margin-top:50%
}
.jumbotron {
   background-image:url("img/stat.png");
   background-repeat:no-repeat;
   background-position:85% 20%
}
body  {
  background-color:#353b48;
  background-image: url("img/child2.png");
  background-repeat:no-repeat;
  
  background-position:90% 70%
}
}
</style>
