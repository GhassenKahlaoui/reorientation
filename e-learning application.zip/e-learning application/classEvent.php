 <?php 

 class Event {
    private $nomEvent , $numEvent , $descEvent , $salleEvent ; 
    private  $formateurNumer , $formateurNom; 
    function __construct($numevt , $nomEvt , $descEvt , $salleEvent ,  Formateur $f) {
        $this->numEvent = $numevt ; 
        $this->nomEvent = $nomEvt ; 
        $this->description = $descEvt ;
        $this->$salleEvent = $salleEvent;
        $this->formateurNumer = $f->getFormateurCin();
        $this->formateurNom = $f->getFormateurNom();
    }

    /****** les getters  ****/



    // returner le nom de l'evennement
    public function getFormateurNumero() {
        return $this->formateurNumer;
    }
    
    public function getformateurNom() {
        return $this->formateurNom;
    }
    public function  getNomEvent() {
        return $this->nomEvent ; 
    } 

    // retourner le numero de l'evennement
    function getNumEvent() {
        return $this->numEvent ; 
    } 

    // retourner la description de l'evennement 
    function getDes() {
        return $this->description ; 
    } 

    // retourner la salle de l'evenemment 
    public  function getSalleEvent() {
        return $this->salleEvent ; 
    } 
    


}
?>