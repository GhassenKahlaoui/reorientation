-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : lun. 31 juil. 2023 à 12:02
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `it_plus`
--

-- --------------------------------------------------------

--
-- Structure de la table `animateur`
--

CREATE TABLE `animateur` (
  `CinAnimateur` varchar(8) NOT NULL,
  `EmailAnimateur` varchar(100) DEFAULT NULL,
  `Nomanimateur` varchar(20) DEFAULT NULL,
  `PrenomAnimateur` varchar(20) DEFAULT NULL,
  `MPSSAnimateur` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `animateur`
--

INSERT INTO `animateur` (`CinAnimateur`, `EmailAnimateur`, `Nomanimateur`, `PrenomAnimateur`, `MPSSAnimateur`) VALUES
('', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `animation`
--

CREATE TABLE `animation` (
  `ident_Animation` varchar(10) NOT NULL,
  `NomAnimation` varchar(100) DEFAULT NULL,
  `DescriptionAnimation` varchar(200) DEFAULT NULL,
  `Date_De_Creation` varchar(10) DEFAULT NULL,
  `Nom_animation` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `animation`
--

INSERT INTO `animation` (`ident_Animation`, `NomAnimation`, `DescriptionAnimation`, `Date_De_Creation`, `Nom_animation`) VALUES
('17', 'Scratch', 'init au scratch', '2020-12-25', 'video-1606401624.mp4');

-- --------------------------------------------------------

--
-- Structure de la table `apprenant`
--

CREATE TABLE `apprenant` (
  `CinApprenant` varchar(8) NOT NULL,
  `EmailApprenant` varchar(100) DEFAULT NULL,
  `NomApprenant` varchar(20) DEFAULT NULL,
  `PrenomApprenant` varchar(20) DEFAULT NULL,
  `MPS_Apprenant` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `apprenant`
--

INSERT INTO `apprenant` (`CinApprenant`, `EmailApprenant`, `NomApprenant`, `PrenomApprenant`, `MPS_Apprenant`) VALUES
('1234585', 'ihebayadi@gmail.com', 'iheb', 'iheb', '123054'),
('Enter Vo', 'iheb@gmail.com', 'Enter Votre PrÃ©nom', 'Enter Votre PrÃ©nom', 'Enter qsdf');

-- --------------------------------------------------------

--
-- Structure de la table `apprenant_utilisatur`
--

CREATE TABLE `apprenant_utilisatur` (
  `num` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `apprenant_utilisatur`
--

INSERT INTO `apprenant_utilisatur` (`num`, `email`, `code`) VALUES
(5, 'ihebayadi@gmail.com', 'ghassenkahlaoui'),
(6, 'ihebayadi@gmail.com', 'ghassenkahlaoui');

-- --------------------------------------------------------

--
-- Structure de la table `encadreur`
--

CREATE TABLE `encadreur` (
  `CinEncadreur` varchar(8) NOT NULL,
  `EmailEncadreur` varchar(100) DEFAULT NULL,
  `NomEncadreur` varchar(20) DEFAULT NULL,
  `PrenomEncadreur` varchar(20) DEFAULT NULL,
  `MPS_Apprenant` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `encadreur`
--

INSERT INTO `encadreur` (`CinEncadreur`, `EmailEncadreur`, `NomEncadreur`, `PrenomEncadreur`, `MPS_Apprenant`) VALUES
('12345678', 'ghassenkahlaoui@gmail.com', 'wajdi', 'saidi ', 'p123');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur_panier`
--

CREATE TABLE `utilisateur_panier` (
  `Num` varchar(100) NOT NULL,
  `Email_Utilisateur` varchar(100) DEFAULT NULL,
  `Indent_Animation` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur_panier`
--

INSERT INTO `utilisateur_panier` (`Num`, `Email_Utilisateur`, `Indent_Animation`) VALUES
('1', 'ghassenkahlaoui@gmail.com', '1'),
('10', 'ghassenkahlaoui@gmail.com', '1'),
('11', 'ghassenkahlaoui@gmail.com', '1'),
('12', 'ghassenkahlaoui@gmail.com', '1'),
('2', 'ghassenkahlaoui@gmail.com', '1'),
('3', 'ghassenkahlaoui@gmail.com', '1'),
('4', 'ghassenkahlaoui@gmail.com', '1'),
('5', 'ghassenkahlaoui@gmail.com', '1'),
('6', 'ghassenkahlaoui@gmail.com', '1'),
('7', 'ghassenkahlaoui@gmail.com', '1'),
('8', 'ghassenkahlaoui@gmail.com', '1'),
('9', 'ghassenkahlaoui@gmail.com', '1');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur_point`
--

CREATE TABLE `utilisateur_point` (
  `CinUtilisateur` varchar(8) NOT NULL,
  `nbPoint` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `animateur`
--
ALTER TABLE `animateur`
  ADD PRIMARY KEY (`CinAnimateur`);

--
-- Index pour la table `animation`
--
ALTER TABLE `animation`
  ADD PRIMARY KEY (`ident_Animation`);

--
-- Index pour la table `apprenant`
--
ALTER TABLE `apprenant`
  ADD PRIMARY KEY (`CinApprenant`);

--
-- Index pour la table `apprenant_utilisatur`
--
ALTER TABLE `apprenant_utilisatur`
  ADD PRIMARY KEY (`num`);

--
-- Index pour la table `encadreur`
--
ALTER TABLE `encadreur`
  ADD PRIMARY KEY (`CinEncadreur`);

--
-- Index pour la table `utilisateur_panier`
--
ALTER TABLE `utilisateur_panier`
  ADD PRIMARY KEY (`Num`);

--
-- Index pour la table `utilisateur_point`
--
ALTER TABLE `utilisateur_point`
  ADD PRIMARY KEY (`CinUtilisateur`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `apprenant_utilisatur`
--
ALTER TABLE `apprenant_utilisatur`
  MODIFY `num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
